﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {

            Button ButtonInformation = new Button();
            Button ButtonProcesses = new Button();
            Button Temperatures = new Button();

            InitializeComponent();
            //GridMenu.SetValue(Grid.ColumnProperty, 0);
            //GridMenu.Background = new SolidColorBrush(Color.FromRgb(26, 14, 181));
            //GridMenu.Width = 230;
            //GridMenu.HorizontalAlignment = HorizontalAlignment.Left;

            ButtonInformation.SetValue(Grid.ColumnProperty, 0);
            ButtonInformation.Content = "Общая информация о системе";
            ButtonInformation.Margin = new Thickness(5);
            ButtonInformation.Height = 37;
            ButtonInformation.Click += ButtonInformation_Click;

            ButtonProcesses.SetValue(Grid.ColumnProperty, 0);
            ButtonProcesses.Content = "Процессы";
            ButtonProcesses.Margin = new Thickness(5);
            ButtonProcesses.Height = 37;
            ButtonProcesses.Click += ButtonProcesses_Click;

            Temperatures.SetValue(Grid.ColumnProperty, 0);
            Temperatures.Content = "Температуры";
            Temperatures.Margin = new Thickness(5);
            Temperatures.Height = 37;
            Temperatures.Click += Temp_Button_Click;



            stack1.Children.Add(ButtonInformation);
            stack1.Children.Add(ButtonProcesses);
            stack1.Children.Add(Temperatures);


            //var way = new Uri(@"/WpfApp1/img/1070.jpg", UriKind.Relative);
            //image.Source = new BitmapImage(way);
            ////image.Source = Bitmap("img/1070.jpg", true);
            //image.SetValue(Grid.ColumnProperty, 0);
            //image.Height = 150;

        }
        Label label = new Label();
        Label label1 = new Label();
        Label label2 = new Label();
        Label label3 = new Label();
        Label label4 = new Label();
        Label label5 = new Label();
        Label label6 = new Label();
        Label label7 = new Label();
        //Label label8 = new Label();
        //Label label9 = new Label();
        //Label label10 = new Label();
        TextBlock textBlock = new TextBlock();
        TextBlock textBlock1 = new TextBlock();
        TextBlock textBlock2 = new TextBlock();
        TextBlock textBlock3 = new TextBlock();
        TextBlock textBlock4 = new TextBlock();
        TextBlock textBlock5 = new TextBlock();
        TextBlock textBlock6 = new TextBlock();
        TextBlock textBlock7 = new TextBlock();

        Grid grid = new Grid();

        ScrollViewer scrollViewer = new ScrollViewer();
        //TextBlock textBlock8 = new TextBlock();
        //TextBlock textBlock9 = new TextBlock();
        //TextBlock textBlock10 = new TextBlock();
        private void ButtonInformation_Click(object sender, RoutedEventArgs e)
        {
            Button back = new Button();
            GridMenu.Visibility = Visibility.Collapsed;
            Grid InformationGuid = new Grid();
            StackPanel stack0 = new StackPanel();
            Button Information = new Button();
            Button VideoCard = new Button();
            Button Proc = new Button();
            Button OperatingMemorie = new Button();

            InformationGuid.VerticalAlignment = VerticalAlignment.Bottom;
            InformationGuid.Height = 400;
            InformationGuid.SetValue(Grid.ColumnProperty, 0);
            InformationGuid.Width = 230;

            stack0.Margin = new Thickness(0, -10, 0, 10);
            stack0.Width = 230;

            Information.SetValue(Grid.ColumnProperty, 0);
            Information.Content = "Общая информация о системе";
            Information.Margin = new Thickness(5);
            Information.Height = 37;
            Information.Click += Back_Click;

            VideoCard.SetValue(Grid.ColumnProperty, 0);
            VideoCard.Content = "Видюха";
            VideoCard.Margin = new Thickness(5);
            VideoCard.Height = 37;
            VideoCard.Click += but_Click;
            //Приложение разработано профессиональным .Netчиком, работающим 8 лет в компании Microsoft
            Proc.SetValue(Grid.ColumnProperty, 0);
            Proc.Content = "Камень";
            Proc.Margin = new Thickness(5);
            Proc.Height = 37;
            Proc.Click += but1_Click;

            OperatingMemorie.SetValue(Grid.ColumnProperty, 0);
            OperatingMemorie.Content = "ОЗУ";
            OperatingMemorie.Margin = new Thickness(5);
            OperatingMemorie.Height = 37;
            OperatingMemorie.Click += but2_Click;

            back.SetValue(Grid.ColumnProperty, 0);
            back.Content = "назад";
            back.Margin = new Thickness(5);
            back.Height = 37;
            back.Click += Back_Click;

            //back.SetValue(Grid.ColumnProperty, 0);
            //back.Content = "назад";
            //back.Margin = new Thickness(5);
            //back.Height = 37;
            //back.Click += Back_Click;





            scrollViewer.SetValue(Grid.ColumnSpanProperty, 3);


            //StackPanel stackPanel = new StackPanel();

            //StackPanel stackPanel = new StackPanel();
            //stackPanel.SetValue(Grid.ColumnProperty, 1);
            //stackPanel.Height = 40;
            //stackPanel.Orientation = Orientation.Horizontal;
            //stackPanel.VerticalAlignment = VerticalAlignment.Top;
            //stackPanel.HorizontalAlignment = HorizontalAlignment.Left;
            //stackPanel.Background = new SolidColorBrush(Color.FromRgb(26, 14, 181));



            string[] logicalDrives = Environment.GetLogicalDrives();






            textBlock.Text = Convert.ToString(Environment.OSVersion);      //версия оси
            textBlock.Margin = new Thickness(485, 57, 0, 0);
            textBlock.TextWrapping = TextWrapping.Wrap;
            textBlock.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label.Content = "Версия Оси";
            label.Margin = new Thickness(280, 52, 0, 0);
            label.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));


            textBlock1.Text = Convert.ToString(Environment.MachineName);            //имя машины
            textBlock1.TextWrapping = TextWrapping.Wrap;
            textBlock1.Margin = new Thickness(textBlock.Margin.Left, textBlock.Margin.Top + 37, textBlock.Margin.Right, textBlock.Margin.Bottom);
            textBlock1.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label1.Content = "Имя машины";
            label1.Margin = new Thickness(label.Margin.Left, label.Margin.Top + 37, label.Margin.Right, label.Margin.Bottom);
            label1.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));


            textBlock2.Text = Convert.ToString(logicalDrives);                     //Диски
            textBlock2.TextWrapping = TextWrapping.Wrap;
            textBlock2.Margin = new Thickness(textBlock1.Margin.Left, textBlock1.Margin.Top + 37, textBlock1.Margin.Right, textBlock1.Margin.Bottom);
            textBlock2.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label2.Content = "Диски";
            label2.Margin = new Thickness(label1.Margin.Left, label1.Margin.Top + 37, label1.Margin.Right, label1.Margin.Bottom);
            label2.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));


            textBlock3.Text = "";          //Количество потоков
            textBlock3.TextWrapping = TextWrapping.Wrap;
            textBlock3.Margin = new Thickness(textBlock2.Margin.Left, textBlock2.Margin.Top + 37, textBlock2.Margin.Right, textBlock2.Margin.Bottom);
            textBlock3.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label3.Content = "";
            label3.Margin = new Thickness(label2.Margin.Left, label2.Margin.Top + 37, label2.Margin.Right, label2.Margin.Bottom);
            label3.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));


            textBlock4.TextWrapping = TextWrapping.Wrap;
            textBlock4.Margin = new Thickness(textBlock3.Margin.Left, textBlock3.Margin.Top + 37, textBlock3.Margin.Right, textBlock3.Margin.Bottom);/*new Thickness(485, 213, 0, 0);*/
            textBlock4.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label4.Margin = new Thickness(label3.Margin.Left, label3.Margin.Top + 37, label3.Margin.Right, label3.Margin.Bottom);/*new Thickness(280, 206, 0, 0);*/
            label4.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));


            textBlock5.TextWrapping = TextWrapping.Wrap;
            textBlock5.Margin = new Thickness(textBlock4.Margin.Left, textBlock4.Margin.Top + 37, textBlock4.Margin.Right, textBlock4.Margin.Bottom);/*new Thickness(485, 247, 0, 0);*/
            textBlock5.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label5.Margin = new Thickness(label4.Margin.Left, label4.Margin.Top + 37, label4.Margin.Right, label4.Margin.Bottom);/*new Thickness(280, 243, 0, 0);*/
            label5.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));

            textBlock6.TextWrapping = TextWrapping.Wrap;
            textBlock6.Margin = new Thickness(textBlock5.Margin.Left, textBlock5.Margin.Top + 37, textBlock5.Margin.Right, textBlock5.Margin.Bottom);/* new Thickness(485, 284, 0, 0);*/
            textBlock6.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label6.Margin = new Thickness(label5.Margin.Left, label5.Margin.Top + 37, label5.Margin.Right, label5.Margin.Bottom);/*new Thickness(280, 280, 0, 0);*/
            label6.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));

            textBlock7.TextWrapping = TextWrapping.Wrap;
            textBlock7.Margin = new Thickness(textBlock6.Margin.Left, textBlock6.Margin.Top + 37, textBlock6.Margin.Right, textBlock6.Margin.Bottom);//485, 321, 0, 0
            textBlock7.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            label7.Margin = new Thickness(label6.Margin.Left, label6.Margin.Top + 37, label6.Margin.Right, label6.Margin.Bottom);//(280,+37,0,0)280, 317, 0, 0
            label7.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));




            stack0.Children.Add(Information);
            stack0.Children.Add(VideoCard);
            stack0.Children.Add(Proc);
            stack0.Children.Add(OperatingMemorie);
            stack0.Children.Add(back);
            InformationGuid.Children.Add(stack0);




            grid.Children.Add(label); grid.Children.Add(label1); grid.Children.Add(label2); grid.Children.Add(label3); grid.Children.Add(label4); grid.Children.Add(label5); grid.Children.Add(label6); grid.Children.Add(label7);//grid.Children.Add(label8); grid.Children.Add(label9); grid.Children.Add(label10);
            grid.Children.Add(textBlock); grid.Children.Add(textBlock1); grid.Children.Add(textBlock2); grid.Children.Add(textBlock3); grid.Children.Add(textBlock4); grid.Children.Add(textBlock5); grid.Children.Add(textBlock6); grid.Children.Add(textBlock7);//grid.Children.Add(textBlock8); grid.Children.Add(textBlock9); grid.Children.Add(textBlock10);
            scrollViewer.Content = grid;
            gridok.Children.Add(scrollViewer);
            gridok.Children.Add(InformationGuid);
            //  gridok.Children.Add(stackPanel);




            //stackPanel.Children.Add(label);
            //stackPanel.Children.Add(label1);
            //stackPanel.Children.Add(label2);
            //stackPanel.Children.Add(label3);
            //stackPanel.Children.Add(textBlock);
            //stackPanel.Children.Add(textBlock1);
            //stackPanel.Children.Add(textBlock2);
            //stackPanel.Children.Add(textBlock3);

            //scrollViewer.Content = stackPanel;




        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow mainWindow = new MainWindow();
            win.Close();
            mainWindow.Show();

        }
        

        private void but2_Click(object sender, RoutedEventArgs e)
        {
            ManagementObjectSearcher searcher12 =
new ManagementObjectSearcher("root\\CIMV2",
"SELECT * FROM Win32_PhysicalMemory");
            textBlock6.Text = "";
            label6.Content = "";
            textBlock7.Text = "";
            label7.Content = "";
            Console.WriteLine("------------- Win32_PhysicalMemory instance --------");
            foreach (ManagementObject queryObj in searcher12.Get())
            {

                label.Content = "Канал";
                textBlock.Text = queryObj["BankLabel"].ToString();
                label1.Content = "Ёмкость";
                textBlock1.Text = Math.Round(System.Convert.ToDouble(queryObj["Capacity"]) / 1024 / 1024 / 1024, 2).ToString();
                label2.Content = "Скорость";
                textBlock2.Text = queryObj["Speed"].ToString();
                //label3.Content = "Канал";
                //textBlock3.Text = queryObj["BankLabel"].ToString();
                //label4.Content = "Ёмкость";
                //textBlock4.Text = Math.Round(System.Convert.ToDouble(queryObj["Capacity"]) / 1024 / 1024 / 1024, 2).ToString();
                //label5.Content = "Скорость";
                //textBlock5.Text = queryObj["Speed"].ToString();
                //Console.WriteLine("BankLabel: {0} ; Capacity: {1} Gb; Speed: {2} ", queryObj["BankLabel"],
                //                  Math.Round(System.Convert.ToDouble(queryObj["Capacity"]) / 1024 / 1024 / 1024, 2),
                //                   queryObj["Speed"]);
            }
        }

        private void but1_Click(object sender, RoutedEventArgs e)
        {




            ManagementObjectSearcher searcher8 =
    new ManagementObjectSearcher("root\\CIMV2",
    "SELECT * FROM Win32_Processor");

            foreach (ManagementObject queryObj in searcher8.Get())
            {
                label.Content = "Name";
                textBlock.Text = queryObj["Name"].ToString();
                label1.Content = "Processor Id";
                textBlock1.Text = queryObj["ProcessorId"].ToString();
                label2.Content = "Количество Ядер";
                textBlock2.Text = queryObj["NumberOfCores"].ToString();
                label3.Content = "Количество потоков";
                textBlock3.Text = Convert.ToString(Environment.ProcessorCount);
                label4.Content = "Максимальная Частота(Гц)";
                textBlock4.Text = queryObj["MaxClockSpeed"].ToString();
                label5.Content = "Разрядность шины(бит)";
                textBlock5.Text = queryObj["DataWidth"].ToString();
                label6.Content = "Размер L2 кэша в байтах";
                textBlock6.Text = queryObj["L2CacheSize"].ToString();
                label7.Content = "Размер L3 кэша в байтах";
                textBlock7.Text = queryObj["L3CacheSize"].ToString();

                //Console.WriteLine("------------- Win32_Processor instance ---------------");
                //Console.WriteLine("Name: {0}", queryObj["Name"]);
                //Console.WriteLine("NumberOfCores: {0}", queryObj["NumberOfCores"]);
                //Console.WriteLine("ProcessorId: {0}", queryObj["ProcessorId"]);
            }
        }

        private void but_Click(object sender, EventArgs e)
        {

            label5.Content = "";
            textBlock5.Text = "";
            label6.Content = "";
            textBlock6.Text = "";
            label7.Content = "";
            textBlock7.Text = "";

            ManagementObjectSearcher searcher11 =
     new ManagementObjectSearcher("root\\CIMV2",
     "SELECT * FROM Win32_VideoController");

            foreach (ManagementObject queryObj in searcher11.Get())
            {
                label.Content = "Caption:";
                textBlock.Text = queryObj["Caption"].ToString();
                label1.Content = "VideoProcessor:";
                textBlock1.Text = queryObj["VideoProcessor"].ToString();
                label2.Content = "Видеопамять:";
                textBlock2.Text = queryObj["AdapterRAM"].ToString() + " байт";
                label3.Content = "Description:";
                textBlock3.Text = queryObj["Description"].ToString();
                label4.Content = "Разрешение:";
                textBlock4.Text = queryObj["CurrentHorizontalResolution"].ToString() + " x " + queryObj["CurrentVerticalResolution"];


            }
        }

        private void ButtonProcesses_Click(object sender, RoutedEventArgs e)
        {
            StackPanel stack0 = new StackPanel();
            stack0.Margin = new Thickness(0, -10, 0, 10);
            stack0.Width = 230;


            GridMenu.Visibility = Visibility.Collapsed;
            ListBox listbox0 = new ListBox();
            Button back = new Button();
            back.SetValue(Grid.ColumnProperty, 0);
            back.Content = "назад";
            back.Margin = new Thickness(5);
            back.Height = 37;
            back.Click += Back_Click;

            Grid ProcessesGrid = new Grid();
            ProcessesGrid.VerticalAlignment = VerticalAlignment.Bottom;
            ProcessesGrid.Height = 400;
            ProcessesGrid.SetValue(Grid.ColumnProperty, 0);
            ProcessesGrid.Width = 230;
            //col.ClearValue();
            //    listbox0.HorizontalAlignment = HorizontalAlignment.Left;
            //listbox0.Margin = new Thickness(402, 0, 0, 0);
            //listbox0.Height = 600;
            //listbox0.Width = 381;
            listbox0.VerticalAlignment = VerticalAlignment.Top;
            listbox0.SetValue(Grid.ColumnProperty, 1);
            listbox0.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            listbox0.Background = new SolidColorBrush(Color.FromRgb(55, 54, 61));
            listbox0.BorderThickness = new Thickness(0);
            System.Diagnostics.Process[] processes;

            processes = System.Diagnostics.Process.GetProcesses(); foreach (System.Diagnostics.Process instance in processes)
            {
                listbox0.Items.Add(instance.Id + " \t " + instance.ProcessName + " \t " + instance.PrivateMemorySize);
            }
            stack0.Children.Add(back);
            ProcessesGrid.Children.Add(stack0);
            gridok.Children.Add(ProcessesGrid);
            gridok.Children.Add(listbox0);


        }
        private void Temp_Button_Click(object sender, RoutedEventArgs e)
        {
            StackPanel stack0 = new StackPanel();
            stack0.Margin = new Thickness(0, -10, 0, 10);
            stack0.Width = 230;


            GridMenu.Visibility = Visibility.Collapsed;
            ListBox listbox0 = new ListBox();
            Button back = new Button();
            back.SetValue(Grid.ColumnProperty, 0);
            back.Content = "назад";
            back.Margin = new Thickness(5);
            back.Height = 37;
            back.Click += Back_Click;

            Grid ProcessesGrid = new Grid();
            ProcessesGrid.VerticalAlignment = VerticalAlignment.Bottom;
            ProcessesGrid.Height = 400;
            ProcessesGrid.SetValue(Grid.ColumnProperty, 0);
            ProcessesGrid.Width = 230;

            TextBlock temp = new TextBlock();
            temp.VerticalAlignment = VerticalAlignment.Top;
            temp.Margin = new Thickness(485, 57, 0, 0);
            temp.TextWrapping = TextWrapping.Wrap;
            temp.Foreground = new SolidColorBrush(Color.FromRgb(0, 186, 0));
            temp.SetValue(Grid.RowProperty, 1);
         
            temp.Text = "Эта задача(мониторинг температур) оказалась не выполнимой для меня, я перепробывал около 4-ёх способов: WMI, считать через библиотеку программы HardWare Monitor(Написанной на C#), считать через библиотеку программы Core Temp(Написанной на C#) и другие";

            grid.Children.Add(temp);
            stack0.Children.Add(back);
            ProcessesGrid.Children.Add(stack0);
            gridok.Children.Add(ProcessesGrid);
            gridok.Children.Add(grid);
        }
    }
}
